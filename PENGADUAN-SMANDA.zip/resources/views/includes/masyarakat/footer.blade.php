<footer class="mt-3 p-3 text-center bg-white text-sm text-gray-600 dark:text-gray-400 dark:bg-gray-800">
  © {{ now()->year }} TIM IT CLOVER | XI E SMANDA
  <a href="#" class="text-blue-500" target="_blank">Clover Smanda</a>
</footer>